package com.example.imc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SobrePesoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sobre_peso);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //botao fechar
        Button botao = findViewById(R.id.btnFechar);
        botao.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(SobrePesoActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Bundle extras = getIntent().getExtras();
        float imc = getIntent().getFloatExtra("IMC", 0);


        TextView textResultado;
        textResultado = findViewById(R.id.textResultado);

        // Pegando os valores enviados pela outra tela
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            float peso = bundle.getFloat("Peso", 0);
            float altura = bundle.getFloat("Altura", 0);
            float IMC = bundle.getFloat("IMC", 0);

            // Montando a mensagem para exibir na tela
            String resultado = "PESO: " + peso + " kg\n" +
                    "ALTURA: " + altura + " m\n" +
                    "IMC: " + String.format("%.2f", imc);

            textResultado.setText(resultado);
        }
    }
}