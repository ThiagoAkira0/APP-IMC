package com.example.imc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CalculoIMCActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calculo_imcactivity);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //botao fechar
        Button botao = findViewById(R.id.btnFechar);
        botao.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(CalculoIMCActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        //botao limpar
        Button btnLimpar = findViewById(R.id.btnLimpar);
        EditText Peso = findViewById(R.id.editPeso);
        EditText Altura = findViewById(R.id.editAltura);

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Peso.setText("");  // Limpa o campo de peso
                Altura.setText(""); // Limpa o campo de altura
            }
        });

        Button btnCalcular = findViewById(R.id.btnCalculo);
        //clique no botao chama o calcularIMC()
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                calcularIMC();
            }
        });
    }
            private void calcularIMC() {
                EditText Peso, Altura;
                Peso = findViewById(R.id.editPeso);
                Altura = findViewById(R.id.editAltura);

                String pesoString = Peso.getText().toString();
                String alturaString = Altura.getText().toString();
                //código para validação de dados
                if (!pesoString.isEmpty() && !alturaString.isEmpty()) {
                    try {
                        float peso = Float.parseFloat(pesoString);
                        float altura = Float.parseFloat(alturaString);

                        if (altura > 0) {
                            float imc = peso / (altura * altura);
                            TelaResultado(imc, altura, peso);
                        } else {
                            Altura.setError("Altura deve ser maior que zero!");
                        }
                    } catch (NumberFormatException e) {
                        Peso.setError("Digite um número válido!");
                        Altura.setError("Digite um número válido!");
                    }
                } else {
                    if (pesoString.isEmpty()) Peso.setError("Preencha este campo!");
                    if (alturaString.isEmpty()) Altura.setError("Preencha este campo!");
                }
            }
            //Condições para ir para a tela correspondente
            private void TelaResultado(float imc, float altura, float peso){
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
            if (imc<18.5){
                intent = new Intent(this, AbaixoDoPesoActivity.class);
            }
            else if(imc>=18.5 && imc<25){
                intent = new Intent(this, PesoNormalActivity.class);
            }
            else if(imc>=25 && imc<30){
                intent = new Intent(this, SobrePesoActivity.class);
            }
            else if(imc>=30 && imc<35){
                intent = new Intent(this, Obesidade1Activity.class);
            }
            else if(imc>=35 && imc<40){
                intent = new Intent(this, Obesidade2Activity.class);
            }
            else if(imc>=40){
                intent = new Intent(this, Obesidade3Activity.class);
            }
                bundle.putFloat("IMC", imc);
                bundle.putFloat("Altura", altura);
                bundle.putFloat("Peso", peso);
                intent.putExtras(bundle);

                startActivity(intent);
    }
}